"""
plot_serve.py

3D animated skeleton viewer for serve CSVs.

Usage:
    U mode — raw points, no labels:
        python plot_serve.py U <csv>

    L mode — auto-assign body parts via label_markers.py:
        python plot_serve.py L <csv>

    M mode — read body part names directly from CSV header (merged/labeled files):
        python plot_serve.py M <csv>

    S mode — annotated peak CSV produced by find_peaks.py:
        python plot_serve.py S <csv>

Examples:
    python plot_serve.py U data\\14unL.csv
    python plot_serve.py M data\\14unL_labeled.csv
    python plot_serve.py S data\\14unL_peaks.csv

Controls:
    - Animation plays automatically
    - Click and drag to rotate the 3D view
    - Close the window to exit
"""

import sys
import os
import csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as mpatches

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from read_serve import read_serve

# Bones for labeled/merged modes
BONES_LABELED = [
    ("head",           "chest"),
    ("chest",          "leftshoulder"),
    ("chest",          "rightshoulder"),
    ("leftshoulder",   "rightshoulder"),
    ("leftshoulder",   "leftelbow"),
    ("leftelbow",      "lefthand"),
    ("rightshoulder",  "rightelbow"),
    ("rightelbow",     "righthand"),
    ("chest",          "lefthip"),
    ("chest",          "righthip"),
    ("lefthip",        "righthip"),
    ("lefthip",        "leftknee"),
    ("leftknee",       "leftfoot"),
    ("righthip",       "rightknee"),
    ("rightknee",      "rightfoot"),
]

MARKER_COLORS = [
    "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd",
    "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf",
    "#f7b733", "#00c957", "#6a0dad", "#e6194b",
]

PART_COLORS = {
    "head":          "#1f77b4",
    "chest":         "#9467bd",
    "leftshoulder":  "#ff7f0e",
    "rightshoulder": "#e377c2",
    "leftelbow":     "#d62728",
    "rightelbow":    "#2ca02c",
    "lefthand":      "#8c564b",
    "righthand":     "#17becf",
    "lefthip":       "#6a0dad",
    "righthip":      "#f7b733",
    "leftknee":      "#7f7f7f",
    "rightknee":     "#bcbd22",
    "leftfoot":      "#00c957",
    "rightfoot":     "#e6194b",
}


def padded_limits(arrays, pad=0.08):
    flat = np.concatenate([a for a in arrays if len(a) > 0])
    lo, hi = np.nanmin(flat), np.nanmax(flat)
    margin = (hi - lo) * pad
    return lo - margin, hi + margin


def read_merged_csv(filepath):
    raw = pd.read_csv(filepath, header=None, dtype=str)
    part_names = []
    col = 2
    while col < raw.shape[1]:
        name = str(raw.iloc[0, col]).strip()
        part_names.append(name if name and name != 'nan' else f"marker_{len(part_names)}")
        col += 3

    data_rows = raw.iloc[3:].reset_index(drop=True)
    frames = pd.to_numeric(data_rows.iloc[:, 0], errors="coerce").values

    result = {"frames": frames}
    for i, name in enumerate(part_names):
        col = 2 + i * 3
        result[name] = {
            "TX": pd.to_numeric(data_rows.iloc[:, col],     errors="coerce").values,
            "TY": pd.to_numeric(data_rows.iloc[:, col + 1], errors="coerce").values,
            "TZ": pd.to_numeric(data_rows.iloc[:, col + 2], errors="coerce").values,
        }
    return result


def make_axes(ax, x_lim, y_lim, z_lim, x_range, y_range, z_range):
    ax.set_xlim(*x_lim)
    ax.set_ylim(*y_lim)
    ax.set_zlim(*z_lim)
    ax.set_box_aspect([x_range, y_range, z_range])
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z (height)")


# ── S MODE HELPERS ─────────────────────────────────────────────────────────────

def read_peaks_csv(filepath):
    """
    Read a _peaks.csv produced by find_peaks.py.
    Metadata lines at the top:
        PEAK1=<frame_idx>,<col_name>,<label>
        PEAK2=<frame_idx>,<col_name>,<label>
        LABEL=<track>,<body_part_name>
        ...
    Remaining lines are the original Vicon CSV.

    Returns:
        df         : DataFrame (parsed Vicon data)
        tz_cols    : list of TZ column names
        peaks      : list of two dicts {frame_idx, col, label, color}
        track_labels: dict of { track_base: label } e.g. {'Track1045': 'ball_hand'}
    """
    import io

    with open(filepath, 'r') as f:
        lines = f.readlines()

    meta_peaks  = {}
    track_labels = {}
    data_start_line = 0

    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("PEAK1="):
            parts = stripped[6:].split(",", 2)
            meta_peaks['peak1'] = {
                'frame_idx': int(parts[0]),
                'col':       parts[1].strip(),
                'label':     parts[2].strip() if len(parts) > 2 else 'Ball Toss',
                'color':     '#ffd166',
            }
        elif stripped.startswith("PEAK2="):
            parts = stripped[6:].split(",", 2)
            meta_peaks['peak2'] = {
                'frame_idx': int(parts[0]),
                'col':       parts[1].strip(),
                'label':     parts[2].strip() if len(parts) > 2 else 'Follow Through',
                'color':     '#06d6a0',
            }
        elif stripped.startswith("LABEL="):
            parts = stripped[6:].split(",", 1)
            if len(parts) == 2:
                track_labels[parts[0].strip()] = parts[1].strip()
        else:
            data_start_line = i
            break

    if 'peak1' not in meta_peaks or 'peak2' not in meta_peaks:
        raise ValueError("File is missing PEAK1/PEAK2 metadata lines. Was it produced by find_peaks.py?")

    vicon_text = "".join(lines[data_start_line:])
    raw = pd.read_csv(io.StringIO(vicon_text), header=None, low_memory=False)

    marker_row    = raw.iloc[0].fillna("").tolist()
    component_row = raw.iloc[1].fillna("").tolist()

    col_labels = []
    current_marker = ""
    for i, (m, c) in enumerate(zip(marker_row, component_row)):
        m = str(m).strip()
        c = str(c).strip()
        if m:
            current_marker = m
        if i == 0:
            col_labels.append("Frame")
        elif i == 1:
            col_labels.append("SubFrame")
        else:
            if "Track" in current_marker and "(" in current_marker:
                track_id = current_marker.split("(")[-1].rstrip(")")
                label = f"Track{track_id}_{c}"
            else:
                label = f"Col{i}_{c}"
            col_labels.append(label)

    df = raw.iloc[3:].reset_index(drop=True)
    df.columns = col_labels
    df = df.apply(pd.to_numeric, errors='coerce')
    df.dropna(how='all', inplace=True)
    df.reset_index(drop=True, inplace=True)

    tz_cols = [
        col_labels[i]
        for i, c in enumerate(component_row)
        if str(c).strip().upper() == 'TZ' and i >= 2
    ]

    peaks = [meta_peaks['peak1'], meta_peaks['peak2']]

    return df, tz_cols, peaks, track_labels


def draw_timeline_bar(fig, current_fi, total_frames, peak1_fi, peak2_fi):
    """
    Draw a persistent segmented timeline bar at the bottom of the figure.
    Three zones: Before Swing | Swing | After Swing
    with a moving cursor for the current frame.
    """
    # Use a dedicated axes anchored to the bottom of the figure
    # (added once, cleared and redrawn each frame)
    ax = fig.axes[-1]  # the timeline axes is always last (added after 3D ax)
    ax.cla()
    ax.set_xlim(0, total_frames)
    ax.set_ylim(0, 1)
    ax.set_yticks([])
    ax.set_xticks([])

    # Zone colors
    BEFORE_COLOR = '#334155'
    SWING_COLOR  = '#f72585'
    AFTER_COLOR  = '#334155'

    swing_width = peak2_fi - peak1_fi

    # Before swing
    ax.barh(0.5, peak1_fi, left=0,        height=0.55, color=BEFORE_COLOR, align='center')
    # Swing
    ax.barh(0.5, swing_width, left=peak1_fi, height=0.55, color=SWING_COLOR, alpha=0.75, align='center')
    # After swing
    ax.barh(0.5, total_frames - peak2_fi, left=peak2_fi, height=0.55, color=AFTER_COLOR, align='center')

    # Zone labels
    def zone_label(x, text, color='white'):
        ax.text(x, 0.5, text, color=color, fontsize=7.5, fontweight='bold',
                ha='center', va='center', clip_on=True)

    zone_label(peak1_fi / 2,                            'Before Swing')
    zone_label(peak1_fi + swing_width / 2,              'Swing',        color='#1a1a2e')
    zone_label(peak2_fi + (total_frames - peak2_fi) / 2,'After Swing')

    # Peak tick marks
    ax.axvline(peak1_fi, color='#ffd166', linewidth=2, zorder=4)
    ax.axvline(peak2_fi, color='#06d6a0', linewidth=2, zorder=4)

    # Moving cursor
    ax.axvline(current_fi, color='white', linewidth=1.5, linestyle='--', zorder=5)

    # Frame counter
    ax.set_xlabel(f'Frame {current_fi} / {total_frames - 1}', color='#aaaaaa', fontsize=8)
    for spine in ax.spines.values():
        spine.set_edgecolor('#333355')
    ax.set_facecolor('#1a1a2e')


# ── S MODE ─────────────────────────────────────────────────────────────────────

def plot_segment_mode(filepath):
    """
    S mode: load a _peaks.csv, animate all markers in 3D,
    label every identified marker by name on every frame,
    highlight peak markers on their peak frames,
    and show a segmented timeline bar at the bottom.
    """
    print(f"[S mode] Reading peaks CSV: {filepath}")
    df, tz_cols, peaks, track_labels = read_peaks_csv(filepath)

    peak1, peak2 = sorted(peaks, key=lambda x: x['frame_idx'])
    peak1_fi = peak1['frame_idx']
    peak2_fi = peak2['frame_idx']

    # Slice to swing segment only
    df = df.iloc[peak1_fi:peak2_fi + 1].reset_index(drop=True)
    total_frames = len(df)

    # Remap peak frame indices to new sliced positions
    peak1_fi = 0
    peak2_fi = total_frames - 1

    print(f"  Peak 1 ({peak1['label']}):  {peak1['col']}  frame {peak1_fi}")
    print(f"  Peak 2 ({peak2['label']}): {peak2['col']}  frame {peak2_fi}")
    print(f"  Total frames: {total_frames}")
    print(f"  Labeled tracks: {len(track_labels)}")
    for track, label in track_labels.items():
        print(f"    {track} → {label}")

    # Peak lookup uses remapped indices (0 = first frame, last = final frame)
    peak_lookup = {
        peaks[0]['col']: {**peaks[0], 'frame_idx': peak1_fi},
        peaks[1]['col']: {**peaks[1], 'frame_idx': peak2_fi},
    }

    # Label colors per body part
    LABEL_COLORS = {
        'head':        '#a78bfa',
        'ball_hand':   '#ffd166',
        'racket_hand': '#06d6a0',
        'elbow1':      '#f72585',
        'elbow2':      '#ff6b6b',
        'shoulder1':   '#b5179e',
        'shoulder2':   '#7209b7',
        'chest':       '#4361ee',
        'hip1':        '#4cc9f0',
        'hip2':        '#3a86ff',
        'knee1':       '#8ecae6',
        'knee2':       '#90e0ef',
        'foot1':       '#caf0f8',
        'foot2':       '#ade8f4',
    }

    # Axis limits
    all_tx, all_ty, all_tz = [], [], []
    for col in tz_cols:
        base = col[:-3]
        tx_col, ty_col = base + "_TX", base + "_TY"
        if tx_col in df.columns:
            all_tx.append(df[tx_col].dropna().values)
        if ty_col in df.columns:
            all_ty.append(df[ty_col].dropna().values)
        all_tz.append(df[col].dropna().values)

    x_lim = padded_limits(all_tx) if all_tx else (-1000, 1000)
    y_lim = padded_limits(all_ty) if all_ty else (-1000, 1000)
    z_lim = padded_limits(all_tz) if all_tz else (0, 2000)
    x_range = x_lim[1] - x_lim[0]
    y_range = y_lim[1] - y_lim[0]
    z_range = z_lim[1] - z_lim[0]

    fig = plt.figure(figsize=(11, 8))
    fig.patch.set_facecolor('#1a1a2e')

    ax3d = fig.add_axes([0.0, 0.18, 1.0, 0.80], projection='3d')
    ax3d.set_facecolor('#1a1a2e')
    ax3d.tick_params(colors='#aaaaaa')

    ax_bar = fig.add_axes([0.07, 0.04, 0.88, 0.10])
    ax_bar.set_facecolor('#1a1a2e')

    def update(fi):
        ax3d.cla()
        ax3d.set_facecolor('#1a1a2e')
        make_axes(ax3d, x_lim, y_lim, z_lim, x_range, y_range, z_range)

        on_peak = next((p for p in peaks if fi == p['frame_idx']), None)
        title_color  = on_peak['color'] if on_peak else 'white'
        title_suffix = f"  ★ {on_peak['label']}" if on_peak else ''
        ax3d.set_title(
            f"Frame {fi + 1} / {total_frames}{title_suffix}",
            color=title_color, fontsize=11, pad=6
        )

        for i, tz_col in enumerate(tz_cols):
            base   = tz_col[:-3]          # e.g. 'Track1045'
            tx_col = base + "_TX"
            ty_col = base + "_TY"

            if tx_col not in df.columns or ty_col not in df.columns:
                continue

            try:
                x = df.loc[fi, tx_col]
                y = df.loc[fi, ty_col]
                z = df.loc[fi, tz_col]
            except KeyError:
                continue

            if any(pd.isna(v) for v in [x, y, z]):
                continue

            body_label = track_labels.get(base)          # e.g. 'head', 'elbow1', None
            is_peak_marker = (tz_col in peak_lookup and fi == peak_lookup[tz_col]['frame_idx'])

            if is_peak_marker:
                p_info = peak_lookup[tz_col]
                color  = p_info['color']
                ax3d.scatter(x, y, z, s=200, color=color,
                             edgecolors='white', linewidths=1.2, zorder=6)
                ax3d.text(x, y, z + z_range * 0.03,
                          f"★ {p_info['label']}",
                          color=color, fontsize=9, fontweight='bold', ha='center')
            elif body_label:
                color = LABEL_COLORS.get(body_label, '#ffffff')
                ax3d.scatter(x, y, z, s=60, color=color,
                             edgecolors='white', linewidths=0.5, zorder=5)
                ax3d.text(x, y, z + z_range * 0.015,
                          body_label,
                          color=color, fontsize=7, ha='center')
            else:
                # Unlabeled marker — small plain dot
                color = MARKER_COLORS[i % len(MARKER_COLORS)]
                ax3d.scatter(x, y, z, s=25, color=color, alpha=0.5, zorder=3)

        draw_timeline_bar(fig, fi, total_frames, peak1_fi, peak2_fi)

    make_axes(ax3d, x_lim, y_lim, z_lim, x_range, y_range, z_range)
    draw_timeline_bar(fig, 0, total_frames, peak1_fi, peak2_fi)

    ani = animation.FuncAnimation(
        fig, update, frames=total_frames, interval=33, repeat=True
    )
    plt.show()


# ── U MODE ─────────────────────────────────────────────────────────────────────
def plot_unlabeled(data):
    marker_keys = [k for k in data if k.startswith("marker_")]
    n_frames = len(data["frames"])
    print(f"Markers: {len(marker_keys)}  Frames: {n_frames}")
    print("Mode: U — raw points only")

    all_x = [data[m]["TX"] for m in marker_keys]
    all_y = [data[m]["TY"] for m in marker_keys]
    all_z = [data[m]["TZ"] for m in marker_keys]
    x_lim, y_lim, z_lim = padded_limits(all_x), padded_limits(all_y), padded_limits(all_z)
    x_range = x_lim[1]-x_lim[0]; y_range = y_lim[1]-y_lim[0]; z_range = z_lim[1]-z_lim[0]

    fig = plt.figure(figsize=(9, 7))
    ax = fig.add_subplot(111, projection="3d")
    fig.suptitle("Unlabeled Markers", fontsize=12)

    def update(fi):
        ax.cla()
        make_axes(ax, x_lim, y_lim, z_lim, x_range, y_range, z_range)
        ax.set_title(f"Frame {int(data['frames'][fi])}  ({fi+1}/{n_frames})")
        for i, m in enumerate(marker_keys):
            x, y, z = data[m]["TX"][fi], data[m]["TY"][fi], data[m]["TZ"][fi]
            if not any(np.isnan(v) for v in [x, y, z]):
                color = MARKER_COLORS[i % len(MARKER_COLORS)]
                ax.scatter(x, y, z, s=60, color=color, zorder=5)
                ax.text(x, y, z, m, fontsize=7, color=color)

    make_axes(ax, x_lim, y_lim, z_lim, x_range, y_range, z_range)
    animation.FuncAnimation(fig, update, frames=n_frames, interval=33, repeat=True)
    plt.tight_layout()
    plt.show()


# ── M MODE ─────────────────────────────────────────────────────────────────────
def plot_merged(filepath):
    data = read_merged_csv(filepath)
    part_names = [k for k in data if k != "frames"]
    n_frames = len(data["frames"])
    print(f"Body parts: {len(part_names)}  Frames: {n_frames}")
    print("Mode: M — reading labels from CSV header")
    print(f"Parts found: {part_names}")

    all_x = [data[p]["TX"] for p in part_names]
    all_y = [data[p]["TY"] for p in part_names]
    all_z = [data[p]["TZ"] for p in part_names]
    x_lim, y_lim, z_lim = padded_limits(all_x), padded_limits(all_y), padded_limits(all_z)
    x_range = x_lim[1]-x_lim[0]; y_range = y_lim[1]-y_lim[0]; z_range = z_lim[1]-z_lim[0]

    norm = {p: p.lower().replace(" ", "").replace("_", "") for p in part_names}
    norm_to_orig = {v: k for k, v in norm.items()}

    def get_xyz(part_name, fi):
        key = norm_to_orig.get(part_name.lower().replace("_", ""), part_name)
        if key not in data:
            return np.nan, np.nan, np.nan
        return data[key]["TX"][fi], data[key]["TY"][fi], data[key]["TZ"][fi]

    fig = plt.figure(figsize=(9, 7))
    ax = fig.add_subplot(111, projection="3d")
    fig.suptitle("Labeled Skeleton", fontsize=12)

    def update(fi):
        ax.cla()
        make_axes(ax, x_lim, y_lim, z_lim, x_range, y_range, z_range)
        ax.set_title(f"Frame {int(data['frames'][fi])}  ({fi+1}/{n_frames})")
        for p in part_names:
            x, y, z = data[p]["TX"][fi], data[p]["TY"][fi], data[p]["TZ"][fi]
            if not any(np.isnan(v) for v in [x, y, z]):
                color = PART_COLORS.get(norm.get(p, p), "#000000")
                ax.scatter(x, y, z, s=40, color=color, zorder=5)
                ax.text(x, y, z, p, fontsize=6, color=color)
        for start, end in BONES_LABELED:
            x0, y0, z0 = get_xyz(start, fi)
            x1, y1, z1 = get_xyz(end, fi)
            if any(np.isnan(v) for v in [x0, y0, z0, x1, y1, z1]):
                continue
            ax.plot([x0, x1], [y0, y1], [z0, z1], "b-", linewidth=1.5, alpha=0.6)

    make_axes(ax, x_lim, y_lim, z_lim, x_range, y_range, z_range)
    animation.FuncAnimation(fig, update, frames=n_frames, interval=33, repeat=True)
    plt.tight_layout()
    plt.show()


# ── L MODE ─────────────────────────────────────────────────────────────────────
def plot_labeled(data):
    from label_markers import label_markers, BODY_PARTS, _mean_position
    n_frames = len(data["frames"])
    print("Labeling markers...")
    labels = label_markers(data)

    print("\n=== Label Assignments ===")
    for part in BODY_PARTS:
        marker = labels[part]
        if marker:
            tx, ty, tz = _mean_position(data, marker)
            print(f"  {part:<20} → {marker}  (TZ={tz:.1f})")
        else:
            print(f"  {part:<20} → None  ✗ MISSING")

    if labels.get("_warnings"):
        print("\n=== Warnings ===")
        for w in labels["_warnings"]:
            print(f"  ⚠ {w}")

    def get_xyz(part, fi):
        marker = labels.get(part)
        if marker is None:
            return np.nan, np.nan, np.nan
        return data[marker]["TX"][fi], data[marker]["TY"][fi], data[marker]["TZ"][fi]

    all_x = [data[labels[p]]["TX"] for p in BODY_PARTS if labels.get(p)]
    all_y = [data[labels[p]]["TY"] for p in BODY_PARTS if labels.get(p)]
    all_z = [data[labels[p]]["TZ"] for p in BODY_PARTS if labels.get(p)]
    x_lim, y_lim, z_lim = padded_limits(all_x), padded_limits(all_y), padded_limits(all_z)
    x_range = x_lim[1]-x_lim[0]; y_range = y_lim[1]-y_lim[0]; z_range = z_lim[1]-z_lim[0]

    fig = plt.figure(figsize=(9, 7))
    ax = fig.add_subplot(111, projection="3d")
    fig.suptitle("Labeled Markers", fontsize=12)

    def update(fi):
        ax.cla()
        make_axes(ax, x_lim, y_lim, z_lim, x_range, y_range, z_range)
        ax.set_title(f"Frame {int(data['frames'][fi])}  ({fi+1}/{n_frames})")
        for part in BODY_PARTS:
            x, y, z = get_xyz(part, fi)
            if not any(np.isnan(v) for v in [x, y, z]):
                color = PART_COLORS.get(part, "#000000")
                ax.scatter(x, y, z, s=40, color=color, zorder=5)
                ax.text(x, y, z, part.replace("_", " "), fontsize=5, color=color)
        for start, end in BONES_LABELED:
            x0, y0, z0 = get_xyz(start, fi)
            x1, y1, z1 = get_xyz(end, fi)
            if any(np.isnan(v) for v in [x0, y0, z0, x1, y1, z1]):
                continue
            ax.plot([x0, x1], [y0, y1], [z0, z1], "b-", linewidth=1.5, alpha=0.6)

    make_axes(ax, x_lim, y_lim, z_lim, x_range, y_range, z_range)
    animation.FuncAnimation(fig, update, frames=n_frames, interval=33, repeat=True)
    plt.tight_layout()
    plt.show()


# ── MAIN ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage:")
        print("  python plot_serve.py U <csv>   — raw points only")
        print("  python plot_serve.py M <csv>   — read labels from CSV header")
        print("  python plot_serve.py L <csv>   — auto-label via label_markers.py")
        print("  python plot_serve.py S <csv>   — peak-annotated CSV from find_peaks.py")
        sys.exit(1)

    mode     = sys.argv[1].upper()
    csv_path = sys.argv[2]

    if not os.path.exists(csv_path):
        print(f"File not found: {csv_path}")
        sys.exit(1)

    if mode == "U":
        data = read_serve(csv_path)
        plot_unlabeled(data)
    elif mode == "M":
        plot_merged(csv_path)
    elif mode == "L":
        data = read_serve(csv_path)
        plot_labeled(data)
    elif mode == "S":
        plot_segment_mode(csv_path)
    else:
        print(f"Unknown mode '{mode}' — use U, M, L, or S.")
        sys.exit(1)
